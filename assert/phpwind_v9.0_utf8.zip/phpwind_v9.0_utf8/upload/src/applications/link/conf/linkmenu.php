<?php
defined('WEKIT_VERSION') or exit(403);
return array(
	'operations' => array('运营', array()), 
	'link_link' => array('友情链接', 'link/link/*', '', '', 'operations'), 
);