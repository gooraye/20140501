<?php

/**
 * 用户引导--兴趣爱好
 *
 * @author xiaoxia.xu <x_824@sina.com>
 * @copyright ©2003-2103 phpwind.com
 * @license http://www.windframework.com
 * @version $Id: InterestController.php 5544 2012-03-06 09:55:31Z xiaoxia.xuxx $
 * @package src.modules.guide.controller
 */
class InterestController extends PwBaseController {
	
	/* (non-PHPdoc)
	 * @see WindController::run()
	 */
	public function run() {
		
	}
}